TAREA: SISTEMA ACADÉMICO

Requisitos: Python 3.10 o superior. No requiere instalar paquetes externos.

Archivos:
- models.py: ModeloBase, Persona, Estudiante, Materia y Matricula.
- views.py: persistencia JSON, operaciones CRUD y reglas de negocio.
- main.py: menús de consola.
- data/: se crean automáticamente estudiantes.json, materias.json y matriculas.json.
- DIAGRAMA_UML.txt: guía para dibujar el diagrama UML.

Ejecución:
1. Extrae el ZIP.
2. Abre esta carpeta en Visual Studio Code.
3. Abre la terminal en esta carpeta y ejecuta: python main.py
4. Registra primero un estudiante, luego una materia y después la matrícula.

Al matricular, el cupo baja en uno. Al retirar la matrícula, se libera un cupo.
