from abc import ABC, abstractmethod
from datetime import date

class ModeloBase(ABC):
    CAMPOS = ()
    def __init__(self, id_registro): self.id = int(id_registro)
    @classmethod
    def desde_diccionario(cls, datos):
        return cls(datos['id'], **{campo: datos[campo] for campo in cls.CAMPOS})
    @abstractmethod
    def a_diccionario(self): pass
    @abstractmethod
    def etiqueta(self): pass

class Persona(ModeloBase):
    CAMPOS = ('nombre','apellido','email')
    def __init__(self, id_registro, nombre, apellido, email):
        super().__init__(id_registro)
        self.nombre, self.apellido = str(nombre).strip().title(), str(apellido).strip().title()
        self.email = str(email).strip().lower()
    @property
    def nombre_completo(self): return f'{self.nombre} {self.apellido}'
    @staticmethod
    def es_email_valido(email):
        email = str(email).strip()
        return '@' in email and '.' in email.split('@')[-1] and ' ' not in email
    def a_diccionario(self): return {'id':self.id,'nombre':self.nombre,'apellido':self.apellido,'email':self.email}
    def etiqueta(self): return f'{self.nombre_completo} · {self.email}'

class Estudiante(Persona):
    CAMPOS = Persona.CAMPOS + ('carnet','carrera')
    def __init__(self, id_registro, nombre, apellido, email, carnet='', carrera=''):
        super().__init__(id_registro,nombre,apellido,email)
        self.carnet, self.carrera = str(carnet).strip().upper(), str(carrera).strip().title()
    def a_diccionario(self):
        datos = super().a_diccionario(); datos.update(carnet=self.carnet,carrera=self.carrera); return datos
    def etiqueta(self): return f'{self.nombre_completo} · {self.carnet} · {self.carrera}'

class Materia(ModeloBase):
    CAMPOS = ('nombre','codigo','creditos','cupos')
    CUPOS_MAXIMOS = 30
    NOTA_APROBACION = 14
    def __init__(self,id_registro,nombre,codigo,creditos=0,cupos=0):
        super().__init__(id_registro)
        self.nombre, self.codigo = str(nombre).strip().title(), str(codigo).strip().upper()
        self.creditos, self.cupos = int(creditos), int(cupos)
        if not self.nombre: raise ValueError('El nombre de la materia es obligatorio.')
        if len(self.codigo)<3: raise ValueError('El código debe tener al menos 3 caracteres.')
        if not 1<=self.creditos<=10: raise ValueError('Los créditos deben estar entre 1 y 10.')
        if not 0<=self.cupos<=self.CUPOS_MAXIMOS: raise ValueError('Los cupos deben estar entre 0 y 30.')
    @staticmethod
    def es_nota_valida(valor):
        try: return 0 <= float(valor) <= 20
        except (TypeError,ValueError): return False
    def hay_cupo(self): return self.cupos > 0
    def ocupar_cupo(self):
        if not self.hay_cupo(): raise ValueError('La materia no tiene cupos disponibles.')
        self.cupos -= 1
    def liberar_cupo(self):
        if self.cupos < self.CUPOS_MAXIMOS: self.cupos += 1
    def a_diccionario(self): return {'id':self.id,'nombre':self.nombre,'codigo':self.codigo,'creditos':self.creditos,'cupos':self.cupos}
    def etiqueta(self): return f'{self.codigo} · {self.nombre} · {self.creditos} créditos · {self.cupos} cupos'

class Matricula(ModeloBase):
    CAMPOS = ('estudiante_id','materia_id','periodo','nota','fecha')
    def __init__(self,id_registro,estudiante_id,materia_id,periodo='2026-1',nota=0,fecha=None):
        super().__init__(id_registro)
        self.estudiante_id, self.materia_id = int(estudiante_id), int(materia_id)
        self.periodo = str(periodo).strip() or '2026-1'
        self.nota = float(nota); self.fecha = str(fecha or date.today().isoformat())
        if not Materia.es_nota_valida(self.nota): raise ValueError('La nota debe estar entre 0 y 20.')
    def esta_aprobada(self): return self.nota >= Materia.NOTA_APROBACION
    def estado(self): return 'Aprobado' if self.esta_aprobada() else 'Reprobado'
    def a_diccionario(self): return {'id':self.id,'estudiante_id':self.estudiante_id,'materia_id':self.materia_id,'periodo':self.periodo,'nota':self.nota,'fecha':self.fecha}
    def etiqueta(self): return f'Matrícula #{self.id} · estudiante {self.estudiante_id} · materia {self.materia_id} · nota {self.nota:.2f} · {self.estado()}'
