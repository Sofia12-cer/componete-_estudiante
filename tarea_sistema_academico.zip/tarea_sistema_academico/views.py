"""Persistencia JSON y reglas del negocio. No contiene print()."""
import json, os
from datetime import date
from models import Estudiante, Materia, Matricula, Persona
DATA='data'; os.makedirs(DATA,exist_ok=True)
AE=f'{DATA}/estudiantes.json'; AM=f'{DATA}/materias.json'; AK=f'{DATA}/matriculas.json'
def _reg(ruta):
    if not os.path.exists(ruta):
        with open(ruta,'w',encoding='utf-8') as f: json.dump([],f)
    with open(ruta,encoding='utf-8') as f: return json.load(f)
def _guardar(ruta,objetos):
    with open(ruta,'w',encoding='utf-8') as f: json.dump([x.a_diccionario() for x in objetos],f,ensure_ascii=False,indent=2)
def leer_objetos(ruta,modelo): return [modelo.desde_diccionario(x) for x in _reg(ruta)]
def obtener_por_id(objetos,ident): return next((x for x in objetos if x.id==int(ident)),None)
def buscar(objetos,termino,campos):
    termino=str(termino).lower().strip()
    return [x for x in objetos if any(termino in str(getattr(x,c,'')).lower() for c in campos)]
def siguiente_id(objetos): return max((x.id for x in objetos),default=0)+1
def ids_registrados(objetos): return {x.id for x in objetos} # set para consultar IDs rápidamente
def indice_por_id(objetos): return {x.id:x for x in objetos} # dict para búsquedas directas

def _respuesta(ok,msg): return (ok,msg) # tupla para estandarizar respuestas

def _carnets(excepto=None): return {r['carnet'].upper() for r in _reg(AE) if r['id']!=excepto} # set para duplicados
def _emails(excepto=None): return {r['email'].lower() for r in _reg(AE) if r['id']!=excepto}
def validar_estudiante(d,id_actual=None):
    if id_actual is None:
        faltan=[c for c in ('nombre','apellido','email','carnet','carrera') if not str(d.get(c,'')).strip()]
        if faltan: return 'Campos obligatorios: '+', '.join(faltan)
    email=str(d.get('email','')).strip().lower(); carnet=str(d.get('carnet','')).strip().upper()
    if email and not Persona.es_email_valido(email): return 'Correo electrónico inválido.'
    if email and email in _emails(id_actual): return 'Ese correo ya está registrado.'
    if carnet and carnet in _carnets(id_actual): return 'Ese carnet ya está registrado.'
    return None
def crear_estudiante(d):
    e=validar_estudiante(d)
    if e:return _respuesta(False,e)
    xs=leer_objetos(AE,Estudiante)
    try:x=Estudiante(siguiente_id(xs),d['nombre'],d['apellido'],d['email'],d['carnet'],d['carrera'])
    except (ValueError,TypeError) as e:return _respuesta(False,str(e))
    xs.append(x);_guardar(AE,xs);return _respuesta(True,f'Estudiante creado con ID {x.id}.')
def obtener_estudiantes():return leer_objetos(AE,Estudiante)
def obtener_estudiante(i):return obtener_por_id(obtener_estudiantes(),i)
def buscar_estudiantes(t):return buscar(obtener_estudiantes(),t,('nombre','apellido','email','carnet','carrera'))
def actualizar_estudiante(i,c):
    xs=obtener_estudiantes();x=obtener_por_id(xs,i)
    if not x:return _respuesta(False,'No existe ese estudiante.')
    d=x.a_diccionario();d.update({k:v for k,v in c.items() if str(v).strip()})
    e=validar_estudiante(d,int(i))
    if e:return _respuesta(False,e)
    try:y=Estudiante(int(i),d['nombre'],d['apellido'],d['email'],d['carnet'],d['carrera'])
    except (ValueError,TypeError) as e:return _respuesta(False,str(e))
    _guardar(AE,[y if z.id==int(i) else z for z in xs]);return _respuesta(True,'Estudiante actualizado.')
def eliminar_estudiante(i):
    xs=obtener_estudiantes()
    if not obtener_por_id(xs,i):return _respuesta(False,'No existe ese estudiante.')
    if any(m.estudiante_id==int(i) for m in obtener_matriculas()):return _respuesta(False,'No se puede eliminar: tiene matrículas.')
    _guardar(AE,[x for x in xs if x.id!=int(i)]);return _respuesta(True,'Estudiante eliminado.')

def _codigos(excepto=None):return {r['codigo'].upper() for r in _reg(AM) if r['id']!=excepto} # set para códigos únicos
def _validar_materia(d,id_actual=None):
    if id_actual is None:
        f=[c for c in ('nombre','codigo','creditos','cupos') if not str(d.get(c,'')).strip()]
        if f:return 'Campos obligatorios: '+', '.join(f)
    codigo=str(d.get('codigo','')).strip().upper()
    if codigo and codigo in _codigos(id_actual):return 'Ese código ya está registrado.'
    try:creditos,cupos=int(d.get('creditos')),int(d.get('cupos'))
    except (TypeError,ValueError):return 'Créditos y cupos deben ser enteros.'
    if not 1<=creditos<=10:return 'Los créditos deben estar entre 1 y 10.'
    if not 0<=cupos<=Materia.CUPOS_MAXIMOS:return 'Los cupos deben estar entre 0 y 30.'
    return None
def crear_materia(d):
    e=_validar_materia(d)
    if e:return _respuesta(False,e)
    xs=leer_objetos(AM,Materia)
    try:x=Materia(siguiente_id(xs),d['nombre'],d['codigo'],d['creditos'],d['cupos'])
    except (ValueError,TypeError) as e:return _respuesta(False,str(e))
    xs.append(x);_guardar(AM,xs);return _respuesta(True,f'Materia creada con ID {x.id}.')
def obtener_materias():return leer_objetos(AM,Materia)
def obtener_materia(i):return obtener_por_id(obtener_materias(),i)
def buscar_materias(t):return buscar(obtener_materias(),t,('nombre','codigo'))
def materias_sin_cupo():return [m for m in obtener_materias() if not m.hay_cupo()]
def actualizar_materia(i,c):
    xs=obtener_materias();x=obtener_por_id(xs,i)
    if not x:return _respuesta(False,'No existe esa materia.')
    d=x.a_diccionario();d.update({k:v for k,v in c.items() if str(v).strip()})
    e=_validar_materia(d,int(i))
    if e:return _respuesta(False,e)
    try:y=Materia(int(i),d['nombre'],d['codigo'],d['creditos'],d['cupos'])
    except (ValueError,TypeError) as e:return _respuesta(False,str(e))
    _guardar(AM,[y if z.id==int(i) else z for z in xs]);return _respuesta(True,'Materia actualizada.')
def eliminar_materia(i):
    xs=obtener_materias()
    if not obtener_por_id(xs,i):return _respuesta(False,'No existe esa materia.')
    if any(m.materia_id==int(i) for m in obtener_matriculas()):return _respuesta(False,'No se puede eliminar: tiene matrículas.')
    _guardar(AM,[x for x in xs if x.id!=int(i)]);return _respuesta(True,'Materia eliminada.')

def crear_matricula(d):
    es,ms,ks=obtener_estudiantes(),obtener_materias(),obtener_matriculas()
    try:ei,mi=int(d['estudiante_id']),int(d['materia_id'])
    except (KeyError,TypeError,ValueError):return _respuesta(False,'IDs de estudiante y materia inválidos.')
    if ei not in ids_registrados(es):return _respuesta(False,'El estudiante no existe.')
    mat=obtener_por_id(ms,mi)
    if not mat:return _respuesta(False,'La materia no existe.')
    if not mat.hay_cupo():return _respuesta(False,'La materia no tiene cupos disponibles.')
    periodo=str(d.get('periodo') or '2026-1').strip()
    if any(x.estudiante_id==ei and x.materia_id==mi and x.periodo==periodo for x in ks):return _respuesta(False,'Matrícula duplicada para estudiante, materia y período.')
    nota=d.get('nota',0)
    if not Materia.es_nota_valida(nota):return _respuesta(False,'La nota debe estar entre 0 y 20.')
    try:x=Matricula(siguiente_id(ks),ei,mi,periodo,nota,d.get('fecha') or date.today().isoformat());mat.ocupar_cupo()
    except (ValueError,TypeError) as e:return _respuesta(False,str(e))
    ks.append(x);_guardar(AK,ks);_guardar(AM,[mat if z.id==mat.id else z for z in ms]);return _respuesta(True,f'Matrícula creada con ID {x.id}; cupo actualizado.')
def obtener_matriculas():return leer_objetos(AK,Matricula)
def obtener_matricula(i):return obtener_por_id(obtener_matriculas(),i)
def registrar_nota(i,nota):
    xs=obtener_matriculas();x=obtener_por_id(xs,i)
    if not x:return _respuesta(False,'No existe esa matrícula.')
    if not Materia.es_nota_valida(nota):return _respuesta(False,'La nota debe estar entre 0 y 20.')
    x.nota=float(nota);_guardar(AK,xs);return _respuesta(True,'Nota registrada. Estado: '+x.estado()+'.')
def retirar_matricula(i):
    xs=obtener_matriculas();x=obtener_por_id(xs,i)
    if not x:return _respuesta(False,'No existe esa matrícula.')
    ms=obtener_materias();m=obtener_por_id(ms,x.materia_id)
    if m:m.liberar_cupo();_guardar(AM,ms)
    _guardar(AK,[z for z in xs if z.id!=int(i)]);return _respuesta(True,'Matrícula retirada y cupo liberado.')
def certificado(i):
    x=obtener_matricula(i)
    if not x:return None
    # Diccionario índice: permite acceder directamente a estudiante y materia por ID.
    ei=indice_por_id(obtener_estudiantes());mi=indice_por_id(obtener_materias());e=ei.get(x.estudiante_id);m=mi.get(x.materia_id)
    if not e or not m:return 'No se puede generar el certificado: faltan datos relacionados.'
    return '\n'.join([f'CERTIFICADO #{x.id}   período: {x.periodo}',f'Estudiante: {e.nombre_completo} ({e.carnet})',f'Materia: {m.nombre} ({m.codigo}) · {m.creditos} créditos','-'*42,f'Nota: {x.nota:.1f}',f'Estado: {x.estado()}',f'Fecha: {x.fecha}'])
def matriculas_por_estudiante():
    agrupadas={}
    for x in obtener_matriculas():agrupadas.setdefault(x.estudiante_id,[]).append(x) # dict de listas para agrupar matrículas
    return agrupadas
def promedio_de_estudiante(i):
    notas=[x.nota for x in matriculas_por_estudiante().get(int(i),[])]
    return round(sum(notas)/len(notas),2) if notas else 0.0
def resumen():
    es,ms,ks=obtener_estudiantes(),obtener_materias(),obtener_matriculas()
    return {'total_estudiantes':len(es),'carreras':sorted({x.carrera for x in es}),'materias_sin_cupo':[m for m in ms if not m.hay_cupo()],'matriculas_aprobadas':sum(x.esta_aprobada() for x in ks)}
