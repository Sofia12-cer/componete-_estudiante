"""Menús de consola; las reglas del negocio permanecen en views.py."""
import views

def mostrar_lista(objetos):
    if not objetos: print('No hay registros.'); return
    for x in objetos: print(f'ID {x.id}: {x.etiqueta()}')
def mostrar_detalle(objeto):
    if objeto is None: print('No se encontró el registro.')
    else: print(objeto.etiqueta()); print('Datos:',objeto.a_diccionario())
def cambios(campos):
    r={}
    for c in campos:
        v=input(f'{c} (vacío para conservar): ').strip()
        if v:r[c]=v
    return r
def menu_estudiantes():
    while True:
        print('\n--- ESTUDIANTES ---\n1 Crear\n2 Ver todos\n3 Buscar\n4 Ver por ID\n5 Actualizar\n6 Eliminar\n0 Volver');o=input('Opción: ').strip()
        if o=='1':print(*views.crear_estudiante({c:input(c+': ').strip() for c in ('nombre','apellido','email','carnet','carrera')}))
        elif o=='2':mostrar_lista(views.obtener_estudiantes())
        elif o=='3':mostrar_lista(views.buscar_estudiantes(input('Buscar: ')))
        elif o=='4':
            try:mostrar_detalle(views.obtener_estudiante(int(input('ID: '))))
            except ValueError:print('ID inválido.')
        elif o=='5':
            try:print(*views.actualizar_estudiante(int(input('ID: ')),cambios(('nombre','apellido','email','carnet','carrera'))))
            except ValueError:print('ID inválido.')
        elif o=='6':
            try:print(*views.eliminar_estudiante(int(input('ID: '))))
            except ValueError:print('ID inválido.')
        elif o=='0':break
        else:print('Opción inválida.')
def menu_materias():
    while True:
        print('\n--- MATERIAS ---\n1 Crear\n2 Ver todas\n3 Buscar\n4 Ver por ID\n5 Actualizar\n6 Eliminar\n7 Materias sin cupo\n0 Volver');o=input('Opción: ').strip()
        if o=='1':print(*views.crear_materia({c:input(c+': ').strip() for c in ('nombre','codigo','creditos','cupos')}))
        elif o=='2':mostrar_lista(views.obtener_materias())
        elif o=='3':mostrar_lista(views.buscar_materias(input('Buscar: ')))
        elif o=='4':
            try:mostrar_detalle(views.obtener_materia(int(input('ID: '))))
            except ValueError:print('ID inválido.')
        elif o=='5':
            try:print(*views.actualizar_materia(int(input('ID: ')),cambios(('nombre','codigo','creditos','cupos'))))
            except ValueError:print('ID inválido.')
        elif o=='6':
            try:print(*views.eliminar_materia(int(input('ID: '))))
            except ValueError:print('ID inválido.')
        elif o=='7':mostrar_lista(views.materias_sin_cupo())
        elif o=='0':break
        else:print('Opción inválida.')
def menu_matriculas():
    while True:
        print('\n--- MATRÍCULAS ---\n1 Matricular\n2 Ver todas\n3 Registrar nota\n4 Ver certificado\n5 Retirar matrícula\n0 Volver');o=input('Opción: ').strip()
        if o=='1':
            d={'estudiante_id':input('ID estudiante: '),'materia_id':input('ID materia: '),'periodo':input('Período [2026-1]: ').strip() or '2026-1','nota':input('Nota inicial (0-20) [0]: ').strip() or '0'};print(*views.crear_matricula(d))
        elif o=='2':mostrar_lista(views.obtener_matriculas())
        elif o=='3':
            try:print(*views.registrar_nota(int(input('ID matrícula: ')),input('Nota (0-20): ')))
            except ValueError:print('ID o nota inválidos.')
        elif o=='4':
            try:print(views.certificado(int(input('ID matrícula: '))) or 'No existe esa matrícula.')
            except ValueError:print('ID inválido.')
        elif o=='5':
            try:print(*views.retirar_matricula(int(input('ID matrícula: '))))
            except ValueError:print('ID inválido.')
        elif o=='0':break
        else:print('Opción inválida.')
def main():
    while True:
        print('\n========== SISTEMA ACADÉMICO ==========\n1 Estudiantes\n2 Materias\n3 Matrículas\n4 Resumen\n0 Salir');o=input('Seleccione: ').strip()
        if o=='1':menu_estudiantes()
        elif o=='2':menu_materias()
        elif o=='3':menu_matriculas()
        elif o=='4':
            r=views.resumen();print('Total estudiantes:',r['total_estudiantes']);print('Carreras:',', '.join(r['carreras']) or 'Ninguna');print('Materias sin cupo:');mostrar_lista(r['materias_sin_cupo']);print('Matrículas aprobadas:',r['matriculas_aprobadas'])
        elif o=='0':print('Programa finalizado.');break
        else:print('Opción inválida.')
if __name__=='__main__':main()
